// 12% 기준 보정 단가 계산
function calcPriceAt12(price, moisture) {
  const target = 12; // 목표 수분 12%
  const numerator = 100 - target; // 88
  const denominator = 100 - moisture;
  if (denominator <= 0) return NaN;
  return price * (numerator / denominator);
}

function update() {
  const priceInput = document.getElementById("price");
  const moistureInput = document.getElementById("moisture");
  const resultSpan = document.getElementById("resultPrice");
  const descText = document.getElementById("descText");

  const price = parseFloat(priceInput.value);
  const moisture = parseFloat(moistureInput.value);

  if (isNaN(price) || isNaN(moisture) || moisture >= 100 || moisture < 0) {
    resultSpan.textContent = "-";
    descText.innerHTML =
      "원물 가격과 수분 함량을 올바르게 입력해 주세요. (수분은 0~99%)";
    return;
  }

  const p12 = calcPriceAt12(price, moisture);
  const rounded = Math.round(p12 * 100) / 100; // 소수 둘째자리까지

  resultSpan.textContent = rounded.toString();
  descText.innerHTML = `입력하신 사료를 수분 함량 <strong>12%</strong> 기준으로 보정 시 원료사료의 가격은 <strong class="highlight">${rounded}원</strong>입니다.`;
}

document.addEventListener("DOMContentLoaded", () => {
  const priceInput = document.getElementById("price");
  const moistureInput = document.getElementById("moisture");

  priceInput.addEventListener("input", update);
  moistureInput.addEventListener("input", update);

  // 초기 계산 (기본값 원, %)
  update();
});
