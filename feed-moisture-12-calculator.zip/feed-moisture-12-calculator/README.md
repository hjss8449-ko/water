# Feed Moisture 12% Calculator

A Pen created on CodePen.

Original URL: [https://codepen.io/hjss/pen/GgZOXEo](https://codepen.io/hjss/pen/GgZOXEo).

